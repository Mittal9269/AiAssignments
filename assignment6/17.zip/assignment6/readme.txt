To run the file use
$ python 17.py > output.txt

And answer will be present in output.txt
To get the better view please run the 17.ipynb in junior notebook -> to run any cell use Enter + shift and run all the 5 cells.
