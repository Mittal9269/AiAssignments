Command to run the code is "python 17.py n k b tt > output.txt"

where, n is number of variables, k is number of clauses,
b is beam width used in beam search, tt is tabu tenure used in tabu search,

"generate.py" file is used to generate random clauses for given n and k; "input.txt" file contain all the clauses; "output.txt" contains all the output of search results